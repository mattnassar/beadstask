function meanCentVar=meanCentVar(var)
    meanCentVar=var-nanmean(var);