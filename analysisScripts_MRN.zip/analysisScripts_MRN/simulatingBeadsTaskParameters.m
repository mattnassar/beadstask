

% trialData
% maxUrnProb
% startLeft
% startRight
% hiValSide (0 = left, 1 = right)
% infCost
% hiValue
% loValue
% inValue

close all

allPenalties=0:-1:-100;
for i=1:length(allPenalties)

    trialData.startLeft =0:40;
    trialData.startRight=ones(size(trialData.startLeft)).*20;
    trialData.maxUrnProb =ones(size(trialData.startLeft)).*.6;
    trialData.hiValSide =true(size(trialData.startLeft));
    trialData.infCost =ones(size(trialData.startLeft)).*.1;
    trialData.hiValue =ones(size(trialData.startLeft)).*70;
    trialData.loValue =ones(size(trialData.startLeft)).*10;
    trialData.inValue =ones(size(trialData.startLeft)).*allPenalties(i);
    trialData.corrUrnSide=true(size(trialData.startLeft));
    trialData=straightStruct(trialData);    
    [infoData, modBehav, condInfoMetrics]=getInfoValueFromBlock(trialData, 100)
    
    
    
    doDraw(:,i)=(modBehav.choiceProbs(:,3)>.5);
    
    
end

evidence=trialData.startRight-trialData.startLeft;

hold on
imagesc(allPenalties, evidence,  doDraw, [0, 1])
plot([-100, 0], [0, 0], '--k')
ylabel('evidence for high value side')
xlabel('penalty')
saveas(gcf, 'penaltyEffects.eps','epsc2')



hold on
ylabel('optimal choice prob')
xlabel('evidence for high value option')


plot(trialData.startRight-trialData.startLeft,   infoData.modTrialInfValue./max(infoData.modTrialInfValue), 'g')
ff=legend('choose low', 'choose high', 'draw', 'information value');
plot([0, 0], [0, 1], '--k')

set(ff, 'box','off')
set(gca, 'box','off')

saveas(gcf, 'modBehav_penalty100.eps', 'epsc2')




